package com.example.crud_registro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.example.crud_registro.Estudiante.Estudiante;
import com.example.crud_registro.service.EstudianteService;

import jakarta.validation.Valid;

@Controller
@RequestMapping ("/")
public class EstudianteController {
    @Autowired
    private EstudianteService estudianteService;

    @GetMapping({" ","/"})

    public String verPaginaDeInicio(Model model) {
        model.addAttribute("estudiantes", estudianteService.listarTodos());
        return "index";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioDeRegistrarEstudiante(Model model) {
        model.addAttribute("estudiante", new Estudiante());
        return "nuevo_estudiante";
    }

    @PostMapping("/guardar")
    public String guardarEstudiante(@Valid @ModelAttribute("estudiante") Estudiante estudiante, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "nuevo_estudiante";
        }
        estudianteService.guardar(estudiante);
        return "redirect:/";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioDeEditarEstudiante(@PathVariable Long id, Model model) {
        Estudiante estudiante = estudianteService.obtener(id);
        model.addAttribute("estudiante", estudiante);
        return "editar_estudiante";
    }

    @PostMapping("/actualizar/{id}")
    public String actualizarEstudiante(@PathVariable Long id, @Valid @ModelAttribute("estudiante") Estudiante estudiante, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "editar_estudiante";
        }
        Estudiante estudianteExistente = estudianteService.obtener(id);
        estudianteExistente.setNombre(estudiante.getNombre());
        estudianteExistente.setEdad(estudiante.getEdad());
        estudianteExistente.setGrado(estudiante.getGrado());
        estudianteService.guardar(estudianteExistente);
        return "redirect:/";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarEstudiante(@PathVariable Long id) {
        estudianteService.eliminar(id);
        return "redirect:/";
    }
}
