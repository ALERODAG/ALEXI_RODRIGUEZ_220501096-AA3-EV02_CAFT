package com.example.crud_registro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.crud_registro.Estudiante.Estudiante;

public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {
}
