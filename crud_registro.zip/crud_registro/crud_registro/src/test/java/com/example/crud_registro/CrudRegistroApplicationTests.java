package com.example.crud_registro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudRegistroApplicationTests {

	@Test
	void contextLoads() {
	}

}
